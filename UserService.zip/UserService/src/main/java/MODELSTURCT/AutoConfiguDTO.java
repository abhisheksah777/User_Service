package MODELSTURCT;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.example.UserService.DTO.USERDTO;
import com.example.UserService.Entity.User;

@Mapper
public interface AutoConfiguDTO {
//	@Mapping(source=salary ,target = salayincome)
	AutoConfiguDTO mapper = Mappers.getMapper(AutoConfiguDTO.class);
	USERDTO maptoUserDto(User user);

	User maptoUser(USERDTO userDTO);

}
