package com.example.UserService.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.UserService.Entity.User;

@Repository
public interface UserRepo extends JpaRepository<User, Integer> {

}
