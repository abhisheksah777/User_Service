package com.example.UserService.Controller;

import org.mapstruct.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.UserService.DTO.USERDTO;
import com.example.UserService.Entity.User;
import com.example.UserService.Serviceimpl.UserServiceImpl;

import MODELSTURCT.AutoConfiguDTO;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/User")
public class UserController {
	@Autowired
	private UserServiceImpl userServiceimpl;
	@Autowired
	ModelMapper modelmapper;
	@Autowired
	AutoConfiguDTO autoConfiguDTO;

	@PostMapping()
//	@ResponseStatus(value = HttpStatus.CREATED)
	public void postMethodName(@RequestBody User user) {
		USERDTO userdto = modelmapper.map(user, USERDTO.class);
		this.userServiceimpl.insertUser(userdto);
	}

	@GetMapping()
	public void getMethodName() {
//		USERDTO userdto = autoConfiguDTO.maptoUserDto(user);
		this.userServiceimpl.getuser();
	}

}
