package com.example.UserService.Serviceimpl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.UserService.DTO.USERDTO;
import com.example.UserService.Entity.User;
import com.example.UserService.Repository.UserRepo;
import com.example.UserService.Service.UserService;

import MODELSTURCT.AutoConfiguDTO;

@Service
public class UserServiceImpl implements UserService {
	
	
	@Autowired
	private UserRepo userepo;
	@Autowired
	ModelMapper modelmapper;
	@Autowired
	AutoConfiguDTO autoConfiguDTO;

	@Override
	public USERDTO insertUser(USERDTO userdto) {
		User user=modelmapper.map(userdto, User.class);
		User saveUser=userepo.save(user);
		USERDTO userd=modelmapper.map(saveUser, USERDTO.class);
		return userd;
	}

	@Override
	public List<USERDTO> getuser() {
		List<User> user=userepo.findAll();
		USERDTO  fetch=AutoConfiguDTO.mapper.maptoUserDto(user)
		return user.stream().map(user)->AutoConfiguDTO.Mapper
	}

	@Override
	public User getUserById(USERDTO userdto) {
		// TODO Auto-generated method stub
		return null;
	}

}
