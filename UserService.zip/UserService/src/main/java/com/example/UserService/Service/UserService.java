package com.example.UserService.Service;

import java.util.List;

import com.example.UserService.DTO.USERDTO;
import com.example.UserService.Entity.User;

public interface UserService {

	public USERDTO insertUser(USERDTO userdto);
	public List<USERDTO>getuser();
	public User getUserById(USERDTO userdto);

}
